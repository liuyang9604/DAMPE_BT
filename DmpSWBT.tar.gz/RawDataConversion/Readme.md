
#   RawDataConversion of DAMPE software

##  Usage

    1.  install DMPSW firstly (refer to: ../README.md/{How to install DMPSW})

    2.  cd to TestRelease, and run JobOpt_DmpRdc (or, copy job option to anywhere and execute it at there)

##  Alg

    default algorithms (for Product) in here, will compile them as a library at the first time

##  Svc

    basical services (phase independent). will compile them as a library at the first time

##  Extend

    User could extend Alg. by using files in $DMPSWSYS/include/Rdc


