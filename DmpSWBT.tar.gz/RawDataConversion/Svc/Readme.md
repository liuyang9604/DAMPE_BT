
##  basical services

    here are basical services for Rdc

    all header files in include directory will been installed into $DMPSWSYS/include/Rdc
