/*
 *  $Id: DmpRdcEntrance.h, 2014-05-04 15:38:47 DAMPE $
 *  Author(s):
 *    Chi WANG (chiwang@mail.ustc.edu.cn) 07/03/2014
*/

#ifndef DmpRdcEntrance_H
#define DmpRdcEntrance_H

namespace DmpEntrance{
  void RdcExecute();
}

#endif


