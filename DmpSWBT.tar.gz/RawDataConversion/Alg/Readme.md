
## default algorithmes

    this is default algorithmes for Rdc.
    version: Prototype 2014

