
while install this package, should copy

    Connector   -->     /prefix/share/

    DmpRdcInput.infor   -->  /prefix/share/TestRelease/

