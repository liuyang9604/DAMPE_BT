
##  Rdc Connector files

    set cnct files in subdetectors' directories.

    could add more sub-directory under subdetectors
