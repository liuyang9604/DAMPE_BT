
#   Geometry package of DAMPE offline software

##  Schema

    1.  gdml*.xsd comes from: "http://service-spi.web.cern.ch/service-spi/app/releases/GDML/schema/gdml.xsd",
        all gdml files in subDet will read it

    2.  materials.xml stored all materials for DAMPE

##  BT2012

    all gdml files for Beam tes 2012

##  Prototype

    all gdml files for prototype 2014
