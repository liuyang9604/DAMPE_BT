
#   TestRelease of DAMPE offline software

    1.  install all JobOpt* files into /prefix/share/TestRelease

    2.  install all Ex* files into /prefix/share/TestRelease

