
### must existed:

    DmpSimVis.mac and DmpSimGUI.mac

    visual mode is the default mode of simulation, it will read the files the 2 files above at here.

### test macro files:

    examples of macro files to run batch mode of simulation.
    contains "Ex"(means example) in the file name

