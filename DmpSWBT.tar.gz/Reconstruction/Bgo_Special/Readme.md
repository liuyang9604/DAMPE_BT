
##   Special Reconstruction for Bgo

###  Structure

    *   dmpRecL1SBgoEng
    create one commond "dmpRecL1SBgoEng" to find energy deposited in Bgo

