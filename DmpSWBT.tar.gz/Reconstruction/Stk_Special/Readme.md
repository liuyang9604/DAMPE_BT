
To test the executable, cd to the test directory, and do

% DmpRec DmpSimu_Photon_1GeV_iso.root 10

This will run the reconstruction (only STK cluster finding is implemented now) for 10 events.

Or

% DmpRec DmpSimu_Photon_1GeV_iso.root 10 100

This will run for 10 events but skip 100 events.

Quetions and comments to xin.wu@cern.ch
