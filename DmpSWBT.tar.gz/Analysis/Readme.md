
#   Analysis Part of Dampe software

    user analysis environment.

##  Goals

    1.  load published data
    2.  simple event chose
        2.1.  chosing method of sub-detector
        2.2.  global chosing method

##  Development guid

    1.  design some versiual methods
    2.  create a shared library, user can overload the methods above

