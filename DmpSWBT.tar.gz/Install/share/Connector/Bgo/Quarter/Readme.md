
##  connect information of BeamTest 2012

    will read all *.cnct files, in Rdc
    could add note in the end of *.cnct files

