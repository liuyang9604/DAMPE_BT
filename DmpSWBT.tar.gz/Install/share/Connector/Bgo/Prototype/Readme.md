
##  connect information of Prototype 2014

    will read all *.cnct files, in Rdc
    could add note in the end of *.cnct files

