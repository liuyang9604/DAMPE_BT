
#   Event of DAMPE software

##  What are in here:

    1.  all event classes are in this package.

##  Usage

    1.  install DMPSW firstly (refer to: ../README.md/{How to install DMPSW})

    this package will create a shared library, other packages which want to use it, just link the created library and include header files

