/*
 *  $Id: DmpEventStkLinkDef.h, 2014-05-01 21:12:10 DAMPE $
 *  Author(s):
 *    Chi WANG (chiwang@mail.ustc.edu.cn) 22/01/2014
*/

#ifdef __CINT__

#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;

#pragma link C++ class DmpEvtMCStkMSD+;

#endif

