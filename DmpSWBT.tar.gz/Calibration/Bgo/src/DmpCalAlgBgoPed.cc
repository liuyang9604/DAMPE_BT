/*
 *  $Id: DmpCalAlgBgoPed.cc, 2014-04-03 16:37:05 chi $
 *  Author(s):
 *    Chi WANG (chiwang@mail.ustc.edu.cn) 03/04/2014
*/

#include "TClonesArray.h"

#include "DmpCalAlgBgoPed.h"
#include "DmpEventRaw.h"
#include "DmpEvtBgoHit.h"

//-------------------------------------------------------------------
DmpCalAlgBgoPed::DmpCalAlgBgoPed(const std::string &n)
 :DmpVAlgorithm(n)
{
}

//-------------------------------------------------------------------
DmpCalAlgBgoPed::~DmpCalAlgBgoPed(){
}

//-------------------------------------------------------------------
bool DmpCalAlgBgoPed::Initialize(){

}

//-------------------------------------------------------------------
bool DmpCalAlgBgoPed::Finalize(){
}

//-------------------------------------------------------------------
bool DmpCalAlgBgoPed::ProcessThisEvent(){

}


