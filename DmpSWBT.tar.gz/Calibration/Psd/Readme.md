
##   Special Calibration for Psd

###  Structure

    *   dmpCalL0SPsdXX
    create one commond "dmpCalL0SPsdXXX" for Psd to find XXX
