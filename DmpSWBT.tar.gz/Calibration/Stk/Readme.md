
##   Special Calibration for Stk

###  Structure

    *   dmpCalL0SStkXX
    create one commond "dmpCalL0SStkXXX" for Stk to find XXX
