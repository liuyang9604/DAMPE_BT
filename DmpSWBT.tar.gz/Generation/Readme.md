
#   Generation Part of Dampe software

##  Goals

    1.  output a file as input of dmpSim

##  Development guid


